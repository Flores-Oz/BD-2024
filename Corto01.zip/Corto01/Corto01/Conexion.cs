﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Corto01
{
    internal class Conexion
    {
        //public static string CADENA = "Data Source=GNARO\\SQLEXPRESS;Initial Catalog=Corto1BD23;Persist Security Info=True;User ID=sa;Password=ImpactRail123";
        public static string CADENA = "Data Source=ALLEGRO\\SQLEXPRESS;Initial Catalog=Corto1BD23;Persist Security Info=True;User ID=sa;Password=GotchardFever456;";
    }
}
