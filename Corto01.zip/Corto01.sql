DECLARE @Carne nvarchar(15);
DECLARE @Semestre int;
DECLARE @Carrera nvarchar(3);
DECLARE @CarreraAdjusted nvarchar(2);
DECLARE @FechaAsignacion smalldatetime = GETDATE();
DECLARE @FechaIngresoNota smalldatetime = GETDATE();

DECLARE StudentCursor CURSOR FOR
SELECT Carne, 
       CAST(SUBSTRING(Carne, 1, 2) AS int) AS Semestre,
       SUBSTRING(Carne, 3, LEN(Carne) - 2) AS Carrera
FROM Alumno;

OPEN StudentCursor;

FETCH NEXT FROM StudentCursor INTO @Carne, @Semestre, @Carrera;

WHILE @@FETCH_STATUS = 0
BEGIN
    IF LEN(@Carrera) = 3
        SET @CarreraAdjusted = SUBSTRING(@Carrera, 2, 2);
    ELSE
        SET @CarreraAdjusted = @Carrera;

    IF @Semestre = 20
        SET @Semestre = 1;
    ELSE IF @Semestre = 19
        SET @Semestre = 3;
    ELSE IF @Semestre = 18
        SET @Semestre = 5;
    ELSE IF @Semestre = 17
        SET @Semestre = 7;
    ELSE IF @Semestre IN (16, 15, 14, 13)
        SET @Semestre = 0;

    IF @Semestre > 0
    BEGIN
        INSERT INTO Asigna_Curso ( Carne, Id_Curso, Zona, F
